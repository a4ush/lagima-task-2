document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const board = document.getElementById('board');
    const status = document.getElementById('status');
    const resetBtn = document.getElementById('reset-btn');
    const themeBtn = document.getElementById('theme-btn');
    const modeBtns = document.querySelectorAll('.mode-btn');
    const xScoreDisplay = document.querySelector('.x-score span');
    const oScoreDisplay = document.querySelector('.o-score span');
    const tiesDisplay = document.querySelector('.ties span');
    const confettiContainer = document.getElementById('confetti');
    
    // Sounds
    const clickSound = document.getElementById('click-sound');
    const winSound = document.getElementById('win-sound');
    const drawSound = document.getElementById('draw-sound');
    
    // Game State
    let boardState = ['', '', '', '', '', '', '', '', ''];
    let currentPlayer = 'X';
    let gameActive = true;
    let gameMode = 'pvp'; // 'pvp' or 'pve'
    let scores = { X: 0, O: 0, ties: 0 };
    
    // Themes
    const themes = [
        { primary: '#ff6b6b', secondary: '#4ecdc4', bg: '#2d3436', cell: '#636e72', text: '#f5f6fa', win: '#fdcb6e' },
        { primary: '#6c5ce7', secondary: '#00b894', bg: '#2d3436', cell: '#636e72', text: '#f5f6fa', win: '#ffeaa7' },
        { primary: '#e84393', secondary: '#0984e3', bg: '#2d3436', cell: '#636e72', text: '#f5f6fa', win: '#fd79a8' },
        { primary: '#fdcb6e', secondary: '#e17055', bg: '#2d3436', cell: '#636e72', text: '#f5f6fa', win: '#00cec9' }
    ];
    let currentTheme = 0;
    
    // Initialize the game
    function initGame() {
        // Create board cells
        board.innerHTML = '';
        for (let i = 0; i < 9; i++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            cell.setAttribute('data-index', i);
            cell.addEventListener('click', handleCellClick);
            board.appendChild(cell);
        }
        
        // Reset board state
        boardState = ['', '', '', '', '', '', '', '', ''];
        currentPlayer = 'X';
        gameActive = true;
        
        // Update status
        updateStatus();
        
        // Remove win highlights
        document.querySelectorAll('.cell').forEach(cell => {
            cell.classList.remove('win');
        });
    }
    
    // Handle cell click
    function handleCellClick(e) {
        if (!gameActive) return;
        
        const index = parseInt(e.target.getAttribute('data-index'));
        
        // If cell is already filled, return
        if (boardState[index] !== '') return;
        
        // Play sound
        clickSound.currentTime = 0;
        clickSound.play();
        
        // Update board state
        boardState[index] = currentPlayer;
        e.target.textContent = currentPlayer;
        e.target.classList.add(currentPlayer.toLowerCase());
        
        // Add animation
        e.target.style.transform = 'scale(0)';
        setTimeout(() => {
            e.target.style.transform = 'scale(1)';
        }, 100);
        
        // Check for winner
        if (checkWin()) {
            endGame(false);
            return;
        }
        
        // Check for draw
        if (checkDraw()) {
            endGame(true);
            return;
        }
        
        // Switch player
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        updateStatus();
        
        // AI move if in PvE mode and it's AI's turn
        if (gameMode === 'pve' && currentPlayer === 'O' && gameActive) {
            setTimeout(makeAIMove, 800);
        }
    }
    
    // AI move logic
    function makeAIMove() {
        if (!gameActive) return;
        
        // Simple AI - first tries to win, then blocks, then random
        let move = findWinningMove('O') || findWinningMove('X') || findRandomMove();
        
        if (move !== null) {
            const cell = document.querySelector(`.cell[data-index="${move}"]`);
            cell.click();
        }
    }
    
    // Find a winning move for the given player
    function findWinningMove(player) {
        // Check rows
        for (let i = 0; i < 9; i += 3) {
            const row = [boardState[i], boardState[i+1], boardState[i+2]];
            if (row.filter(cell => cell === player).length === 2 && row.includes('')) {
                return i + row.indexOf('');
            }
        }
        
        // Check columns
        for (let i = 0; i < 3; i++) {
            const col = [boardState[i], boardState[i+3], boardState[i+6]];
            if (col.filter(cell => cell === player).length === 2 && col.includes('')) {
                return i + (col.indexOf('') * 3);
            }
        }
        
        // Check diagonals
        const diag1 = [boardState[0], boardState[4], boardState[8]];
        if (diag1.filter(cell => cell === player).length === 2 && diag1.includes('')) {
            return diag1.indexOf('') * 4;
        }
        
        const diag2 = [boardState[2], boardState[4], boardState[6]];
        if (diag2.filter(cell => cell === player).length === 2 && diag2.includes('')) {
            return 2 + (diag2.indexOf('') * 2);
        }
        
        return null;
    }
    
    // Find a random empty cell
    function findRandomMove() {
        const emptyCells = boardState.reduce((acc, cell, index) => {
            if (cell === '') acc.push(index);
            return acc;
        }, []);
        
        if (emptyCells.length > 0) {
            return emptyCells[Math.floor(Math.random() * emptyCells.length)];
        }
        return null;
    }
    
    // Check for win
    function checkWin() {
        const winPatterns = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
            [0, 4, 8], [2, 4, 6]             // diagonals
        ];
        
        for (const pattern of winPatterns) {
            const [a, b, c] = pattern;
            if (boardState[a] && boardState[a] === boardState[b] && boardState[a] === boardState[c]) {
                // Highlight winning cells
                pattern.forEach(index => {
                    document.querySelector(`.cell[data-index="${index}"]`).classList.add('win');
                });
                return true;
            }
        }
        return false;
    }
    
    // Check for draw
    function checkDraw() {
        return !boardState.includes('');
    }
    
    // End the game
    function endGame(isDraw) {
        gameActive = false;
        
        if (isDraw) {
            status.innerHTML = 'Game ended in a <span class="draw">draw!</span>';
            drawSound.play();
            scores.ties++;
            tiesDisplay.textContent = scores.ties;
        } else {
            status.innerHTML = `Player <span class="winner">${currentPlayer}</span> wins!`;
            winSound.play();
            scores[currentPlayer]++;
            if (currentPlayer === 'X') {
                xScoreDisplay.textContent = scores.X;
            } else {
                oScoreDisplay.textContent = scores.O;
            }
            createConfetti();
        }
    }
    
    // Update game status
    function updateStatus() {
        const xSpan = status.querySelector('.x-active');
        const oSpan = status.querySelector('.o-active');
        
        if (currentPlayer === 'X') {
            status.innerHTML = 'Player <span class="x-active">X</span>\'s turn';
        } else {
            status.innerHTML = 'Player <span class="o-active">O</span>\'s turn';
        }
    }
    
    // Create confetti effect
    function createConfetti() {
        confettiContainer.innerHTML = '';
        const colors = ['#ff6b6b', '#4ecdc4', '#fdcb6e', '#a29bfe', '#00b894', '#e84393'];
        
        for (let i = 0; i < 100; i++) {
            const confetti = document.createElement('div');
            confetti.classList.add('confetti');
            confetti.style.left = `${Math.random() * 100}%`;
            confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
            confetti.style.animationDuration = `${Math.random() * 3 + 2}s`;
            confetti.style.width = `${Math.random() * 10 + 5}px`;
            confetti.style.height = `${Math.random() * 10 + 5}px`;
            confettiContainer.appendChild(confetti);
            
            // Remove confetti after animation
            setTimeout(() => {
                confetti.remove();
            }, 5000);
        }
    }
    
    // Change game theme
    function changeTheme() {
        currentTheme = (currentTheme + 1) % themes.length;
        const theme = themes[currentTheme];
        
        document.documentElement.style.setProperty('--primary', theme.primary);
        document.documentElement.style.setProperty('--secondary', theme.secondary);
        document.documentElement.style.setProperty('--bg-color', theme.bg);
        document.documentElement.style.setProperty('--cell-bg', theme.cell);
        document.documentElement.style.setProperty('--text-color', theme.text);
        document.documentElement.style.setProperty('--win-color', theme.win);
    }
    
    // Event Listeners
    resetBtn.addEventListener('click', () => {
        initGame();
    });
    
    themeBtn.addEventListener('click', () => {
        changeTheme();
    });
    
    modeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            modeBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            gameMode = btn.dataset.mode;
            initGame();
        });
    });
    
    // Initialize the game
    initGame();
});